import { FiltroListaPipe } from './filtro-lista.pipe';

describe('FiltroListaPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroListaPipe();
    expect(pipe).toBeTruthy();
  });
});
